import { Animatable, Data } from 'framer'

const scale = Animatable(1)

export default Data({
  scale,
})
