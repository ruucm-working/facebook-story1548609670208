import { Data, animate, Override, Animatable } from 'framer'
import { page, stories, storyItem } from './datas'
import { showStoryItem } from './animate'
import { log } from 'ruucm-util'

window.log = log

export const Stories: Override = () => {
  return {
    top: stories.top,
    bottom: stories.bottom,
  }
}

export const Page: Override = () => {
  return {
    top: page.top,
    bottom: page.bottom,
    left: page.left,
  }
}

export const StoryItem: Override = () => {
  return {
    scale: storyItem.scale,
    onTap: showStoryItem,
  }
}
