import { Animatable, Data } from 'framer'

const scale = Animatable(1)
const width = Animatable(10)

export default Data({
  scale,
  width,
})
