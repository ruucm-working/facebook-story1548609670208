import { animate } from 'framer'
import { stories, page, storyItem } from '../datas'
import { sleep } from '../utils'

const showStoryItem = async () => {
  animate.ease(stories.top, 0)
  animate.ease(stories.bottom, 43)
  animate.ease(page.top, 0)
  animate.ease(page.bottom, 0)
  animate.ease(page.left, 0)

  // animate.ease(storyItem.with, 375)

  // storyItem.with.set(375)

  page.contentWidth = 'stretch'
}

export default showStoryItem
