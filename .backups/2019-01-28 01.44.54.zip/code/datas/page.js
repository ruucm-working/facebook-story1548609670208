import { Animatable, Data } from 'framer'

const top = Animatable(44)
const bottom = Animatable(26)
const left = Animatable(15)

const contentWidth = 'auto'

export default Data({
  top,
  bottom,
  left,
  contentWidth,
})
