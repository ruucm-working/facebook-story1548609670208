import { animate } from 'framer'
import { storyItem, page, stories } from '../datas'
import { sleep } from '../utils'

const showStoryItem = async () => {
  animate.ease(stories.top, 0)
  animate.ease(stories.bottom, 43)
  animate.ease(page.top, 0)
  animate.ease(page.bottom, 0)
  animate.ease(page.left, 0)
}

export default showStoryItem
